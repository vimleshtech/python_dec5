#Example 1: input and output
'''
sid = input('enter id :')
sname = input('enter name :')

print('Student id = ',sid)
print(sname)
'''

#Example 2: Arithmetic operations
n1 = int(input('enter data :'))
n2 = int(input('enter data :'))

#print(type(n1))
#print(type(n2))


n = n1 + n2
print('sum of two numebers :',n)

##
o = n1**n2
print(o)

#
o = n1/n2
print(o)

#
o =n1//n2
print(o)

#
o =n1%n2
print(o)

























