

i =1 # init 
while i<10: #condition 
     print(i)
     i =i+1 # incrment

print(i)

#print in reverse

i =10 # init 
while i>0: #condition 
     print(i)
     i =i-1 # decrement

print(i)

##for
for i in range(1,10):  # from 1 to <10  , default increment is 1
     print(i)
     
for i in range(1000,1201,2):  # from 1 to <10  , default increment is 1
     print(i)


     
for x in range(10,0,-1):  # from 1 to <10  , default increment is 1
     print(x)

     
     
