###
emp = []

while True:
    op = input('enter 1 for add 2 for show 3 for deleve 4 for udpate and 0 for exit')

    if op =='1':
            eid = input('enter eid :')
            ename = input('enter name :')
            esal = input('enter sal :')
            row =[eid,ename,esal] 
            emp.append(row)

    elif op=='2':
            for e in emp:
                print(e)

    elif op=='3':
        '''
        [[1,raman,333],
        [3,jatin,544],
        []]
        '''
        eid = input('enter eid :')
        mid = -1

        for i in range(0,len(emp)):
            if emp[i][0] == eid:
                mid = i 

        if mid>-1:
            emp.remove(emp[mid])
        else:
            print('eid is not found')

    elif op =='4':
        eid = input('enter eid :')
        mid = -1
        for i in range(0,len(emp)):
            if emp[i][0] == eid:
                mid = i 

        if mid>-1:
            ename = input('enter new name : ')
            sal = input('enter new sal  : ')
            emp[mid][1] = ename
            emp[mid][2] = sal 
        else:
            print('eid is not found')

    elif op =='0':
            break 
    else:
            print('invalid choice , pls try again !!!')

    
