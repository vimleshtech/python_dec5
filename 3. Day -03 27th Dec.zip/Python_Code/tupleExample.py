t =(11,222,3,4,55,56)

#return all elements 
print(t)

print(t[0])
print(t[::-1])

if  4 in t:
    print('value matched')
else:
    print('value not matched ')


#reassign the value /update the value 
#t[0] =11 # not allowed 


