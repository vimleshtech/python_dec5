d = {'a':'alpha','b':'beta','c':'ceta',1:'one hundered',100:110}

#print all 
print(d)

#read by key 
print(d['c'])

#add new key 
d['t']='tata'

print(d)

###Example
data = {101:[101,'raman','male',22333],102:[102,'monika','female',22333],103:[101,'raman','male',22333] }

eid = int(input('enter eid to search '))
print(data[eid])

