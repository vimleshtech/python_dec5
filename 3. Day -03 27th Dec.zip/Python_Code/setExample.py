
s ={'lakme','dove','iphone','dove'}

print(s)
