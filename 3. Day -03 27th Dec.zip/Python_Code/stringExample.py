
s = input('enter sentence : ')

#
print(s.upper())

#
print(s.lower())
#
print(s.title())

#
print(s.strip())

#
d = s.replace('a','xy')
print(d)


#
print(len(s))

#
l = list(s)
print(l)


#split
d = s.split(' ')
print(d)


#
if s.endswith('n'):
    print('match')


#
if s.startswith('ra'):
    print('match')
