#Q: B10
unit = int(input('enter e unit :'))

total = 0

if unit<=100:
    total = unit*.40
elif unit<=300:
    total = 40 + (unit-100)*.50
else:
    total = 140 + (unit-300)*.60

total += 50
print('total price :',total)

    

