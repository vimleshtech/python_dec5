a =1
b =3
c =a+b
print('sum of two numebrs :',end='')
print(c)

####
'''
1234
1234
1234
'''

for x in range(1,4):
    for y in range(1,5):
        print(y,end='\t')
    print() #new line

#
'''
1
12
123
'''
for x in range(1,4):
    for y in range(1,x+1):  #1,1
        print(y,end='')
    print() #new line

'''
123
12
1
'''
for x in range(3,0,-1):
    for y in range(1,x+1):  #1,1
        print(y,end='')
    print() #new line












    
        

