#Q: B9
hs = int(input('enter mark :'))
es = int(input('enter mark :'))
cs = int(input('enter mark :'))
ms = int(input('enter mark :'))
ss = int(input('enter mark :'))

total = hs+es+cs+ms+ss
avg = total/5

print(total)
print(avg)
if avg>=60:
    print("First")
elif avg>=50 :
    print("Second")

elif avg>=40 :
    print("Third")
else:
    print("Fail")
    
    
      



