data = [111,222,33,444,22]

#print all value 
print(data)

#len
print(len(data))

#read 2nd element
print(data[1])

#read all elements
for i in range(0,len(data)):
    print(data[i])

#or
for d in data:
    print(d)

#
print(max(data))

#
print(min(data))
#
print(sum(data))
#
data.append(100)
data.append(200)
print(data)
#
data.pop()
print(data)
#
data.insert(2,500)
print(data)

#
data.remove(500)
print(data)
#

data.sort()
print(data)
#slicer
print(data[0])
print(data[0:3])  # from to 2nd
print(data[:3])  # from to 2nd
print(data[-1])  # read from right
print(data[:-1])
#reverse , ::   read from right to left
print(data[::-1])










































    






    


