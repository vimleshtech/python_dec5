import pandas as pd
import matplotlib.pyplot as plt

d = pd.read_csv(r'C:\Users\vkumar15\Desktop\emp.csv')
print(d)
print(d.describe())

print(d.groupby('gender').size())

o = d.groupby('gender').size()

o.plot(kind='line', subplots=False)

plt.show()




