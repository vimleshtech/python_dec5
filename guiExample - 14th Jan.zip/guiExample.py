from tkinter import *

o =  Tk()

l1 = Label(text='Enter First Name :' )
l1.pack()

t1 = Entry()
t1.pack()


l2 = Label(text='Enter Last Name :' )
l2.pack()

t2 = Entry()
t2.pack()

out = Label( )
out.pack()

def event():
     print('you have clicked on button ')
     fn = t1.get()     
     ln = t2.get()

     name =fn +' '+ln
     out.configure(text=name)
     
     
     
b1 = Button(text='Click Me',command=event,fg='green', bg='black')
b1.pack()         

o.mainloop()


 
