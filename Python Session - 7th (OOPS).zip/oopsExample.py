

class employee:
     def newemp(self): #we need to receive at least one argument which is ref of current object
          print('new emp ',self)
          self.eid = input('enter eid :')
          self.ename = input('enter name :')
          self.esal = int(input('enter sal :'))
          
          
     def compute(s):
          s.msal  = s.esal*.18 + s.esal*.10 + s.esal
          s.ysal = s.esal*12
          
     def show(a):
          print('show ',a)
          print(a.eid)
          print(a.ename)
          print(a.msal)
          print(a.ysal)
          

class calc:
     def add(s,a,b):
          c =a+b
          print(c)
     def sub(z,b,c):
          x =b-c
          return x
     
#create object
o =employee()
#print(o)

o.newemp()
o.compute()
o.show()

c = calc()
c.add(11,222)
d = c.sub(4333,3)
print(d)







