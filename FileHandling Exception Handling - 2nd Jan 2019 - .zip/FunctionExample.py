#define function # there are two arguments (a,b)
def add(a,b):
     c =a+b
     print('sum of two numebrs :',c)



#call to function
add(11,2)



     
