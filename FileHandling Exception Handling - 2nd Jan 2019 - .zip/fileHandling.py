def readFile():          
          o = open(r'C:\Users\vkumar15\Desktop\Python Session 31st Dec.txt','r') # read mode

          #print(o)
          #print(o.read())

          #read line by line
          #print(o.readline())
          #print(o.readline())


          d = o.readlines()
          o.close()

          #print(d)
          for r in d:
               print(r)
               

          ##wap to get count of rows from file
          print(len(d))

          ##wap to get count of words from file
          ##wap to get count of particular word 
          wc =0
          pwc = 0
          for r in d:  #function example
               c = r.split(' ')  # ['function','example']
               wc = wc+len(c)
               for w in c:
                    if w =='function':
                         pwc +=1
                         


          print(wc)
          print(pwc)

def writeToFile():
               #new file will be created if file is not exist, w : write mode(data will be overwritten if file is alreaedy exist')
               o = open(r'C:\Users\vkumar15\Desktop\out.txt','a') # read mode
               o.write('test data 123...\n')
               o.close()

     
writeToFile()




     

