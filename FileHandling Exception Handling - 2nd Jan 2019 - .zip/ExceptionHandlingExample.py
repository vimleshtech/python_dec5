n = int(input('enter data :'))
d = int(input('enter data :'))

try:
     if d<0:
          er = ZeroDivisionError('divisior cannot be less than 0')
          raise er
     
     o = n/d
     print(o)
     
except ZeroDivisionError as x:
     print(x)
except ValueError as e:
     print(e)
     
except:
     print('invalid input')
finally:
     print('end of block')

o = n+d
print(o)

