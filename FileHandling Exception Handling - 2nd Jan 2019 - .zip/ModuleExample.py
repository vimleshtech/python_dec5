import math

print(math.pi)
print(math.pow(2,10))
print(math.factorial(5))

##
import time

l = time.localtime()
print(l)

print(l.tm_year)
print(l.tm_mon)
print(l.tm_mday)

print(l.tm_mday ,'-', l.tm_mon,'-',l.tm_year)

for i in range(1,10):
     print(i)
     time.sleep(2)#seconds
     
     
