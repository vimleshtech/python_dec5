u=input("unit")
u=int(u)
m=50

if u>=1 and u<=100:
   b= u * 0.4
   t=b + m
   print(t)
elif u>=100 and u<=300:
    b= 40 + (u-100) * 0.5
    t=b + m
    print(t)
elif u>=300:
    b= 140 +(u-300) * 0.6
    t=b+m
    print(t)

   