sal=input("enter the salary")

sal = int(sal)

if sal>=9000:
    it=(40*sal)/100
    print(it)
elif sal>=7500 and sal<=8991:
    it=(30*sal)/100
    print(it)
elif sal<7500:
    it=(20*sal)/100
    print(it)
