#declar variable
a = 10 #here a is variable and 10 is data
b = 20

c = a+b  # expression / logic

print("sum of two numbers: ",c) # show output 

###data type
a =11
print(type(a))


a ='11'
print(type(a))


##input 
fn = input('enter data : ')
ln = input('enter data : ')

fullname  = fn+ln
print('name is : ',fullname)


##WAP to get two numbers from user and show sum
a = input('enter data : ')
b = input('enter data : ')

#type cast
a = int(a) # convert str to int 
b = int(b) # convert str to int

c =a+b
print(c)


