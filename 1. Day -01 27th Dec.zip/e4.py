ch=input("enter")
if ch>='a' and ch<='z':
   print("small letter")
elif ch>='A' and ch<='Z':
    print("capital letter")
elif ch>='0' and ch<='9':
    print("digit")
else:
    print("symbol")