m1=input("first sub")
m2=input("second sub")
m3=input("third sub")
m4=input("fourth sub")
m5=input("fifth sub")
m1= int(m1)
m2= int(m2)
m3= int(m3)
m4= int(m4)
m5= int(m5)
total=m1+m2+m3+m4+m5
avg=(m1+m2+m3+m4+m5)/5
if avg>=60:
   print("first")
elif avg>=50 and avg<=59:
    print("sec")
elif avg>=40 and avg<=49:
    print("third")
elif avg<40:
    print("fail")            
