n=78
o=n*2
print(o)

#
o=2**3
print(o)
#
o=n/10
print(o)

#
o=n//10
print(o)


##
o=n%10
print(o)


##check even and odd numbers 
if o%2 ==0:
    print("even number")
else:
    print("odd number")



##wap to show grade 
hs = 45
es =50
ms =70

total = hs+es+ms 
avg = total/3
print(total)
print(avg)

if avg>80:
    print("A")
elif avg>60:
    print("B")
elif avg>40:
    print("C")
else:
    print("F")

