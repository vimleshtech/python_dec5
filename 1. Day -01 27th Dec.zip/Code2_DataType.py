#int 
a = 11
print(type(a))


#float
a = 11.44
print(type(a))

#str 
a = '11'
print(type(a))

#or
#int 
a = "dd11"
print(type(a))


#bool
b = True 
print(type(b))

#list 
data =[11,222,333]
print(type(data))

print(data)

data[0]=100333
print(data)


#tuple 
t =(11,22,3,4,)
print(type(t))
print(t)

#t[0]=333#error 
#print(t)


#dict 
d ={'a':'alpha','b':'beta','c':'ceta',1:'one',2:200}
print(type(d))

#set 
s = {'dove','lux','dove'}
print(s)
print(type(s))




